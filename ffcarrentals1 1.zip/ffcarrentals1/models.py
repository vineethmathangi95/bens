from django.db import models

class Location(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Rental(models.Model):
    pickup_location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name='pickups')
    pickup_date = models.DateField()
    pickup_time = models.TimeField()
    dropoff_location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name='dropoffs')
    dropoff_date = models.DateField()
    dropoff_time = models.TimeField()

    def __str__(self):
        return f'Rental: {self.pickup_location} - {self.dropoff_location}'
