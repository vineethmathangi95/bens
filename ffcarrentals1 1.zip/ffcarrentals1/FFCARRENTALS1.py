import pymysql


class FFcarrentals1:
    def __init__(self):
        self.con = pymysql.connect(
            host='localhost',
            port=8000,
            user='root',
            password='Abc@1234',
            database='ffcarrentals1'
        )
        self.cur = self.con.cursor()
        self.create_table_users()
        self.create_table_customers()
        self.create_table_locations()
        self.create_table_rentals()
        self.create_table_car_filters()
        self.create_table_payment()

    def create_table_users(self):
        query = 'CREATE TABLE IF NOT EXISTS users(userId INT PRIMARY KEY, username VARCHAR(200), phone VARCHAR(12))'
        self.cur.execute(query)
        self.con.commit()
        print("Users table created")

    def create_table_customers(self):
        query = 'CREATE TABLE IF NOT EXISTS customers(FirstName VARCHAR(50), LastName VARCHAR(50), Mobile_number ' \
                'VARCHAR(100), Email VARCHAR(100), Password VARCHAR(20))'
        self.cur.execute(query)
        self.con.commit()
        print("Customers table created")

    def create_table_locations(self):
        query = 'CREATE TABLE IF NOT EXISTS locations(LocationID INT AUTO_INCREMENT PRIMARY KEY, LocationName ' \
                'VARCHAR(100))'
        self.cur.execute(query)
        self.con.commit()
        print("Locations table created")

        # Inserting locations
        locations = ['Birmingham', 'Coventry', 'London', 'Manchester', 'Edinburgh']
        for index, location in enumerate(locations, start=1):
            insert_query = "INSERT INTO locations (LocationID, LocationName) VALUES (%s, %s)"
            self.cur.execute(insert_query, (index, location))
        self.con.commit()

        print("Locations inserted into Locations table")

    def create_table_rentals(self):
        query = "CREATE TABLE IF NOT EXISTS rentals (\
            RentalID INT PRIMARY KEY,\
            CarID INT,\
            LocationID INT DEFAULT 0,\
            CustomerID INT,\
            PickupLocationID INT,\
            DropoffLocationID INT,\
            PickupDate DATE,\
            PickupTime TIME,\
            DropoffDate DATE,\
            DropoffTime TIME,\
            TotalCost DECIMAL(10, 2),\
            FOREIGN KEY (PickupLocationID) REFERENCES locations(LocationID),\
            FOREIGN KEY (DropoffLocationID) REFERENCES locations(LocationID)\
        )"
        self.cur.execute(query)
        self.con.commit()
        print("Rentals table created")

    def create_table_car_filters(self):
        query = "CREATE TABLE IF NOT EXISTS car_filters (\
            FilterID INT AUTO_INCREMENT,\
            VehicleType VARCHAR(100) NOT NULL,\
            Transmission VARCHAR(100) NOT NULL,\
            Mileage VARCHAR(100) NOT NULL,\
            Fuel VARCHAR(100) NOT NULL,\
            PRIMARY KEY (FilterID)\
        )"
        self.cur.execute(query)
        self.con.commit()
        print("Car Filters table created")

        # Inserting vehicle types
        vehicle_types = ['SUV', 'Sedan', 'Luxury']
        for index, vehicle_type in enumerate(vehicle_types, start=1):
            insert_query = "INSERT INTO car_filters (FilterID, VehicleType) VALUES (%s, %s)"
            self.cur.execute(insert_query, (index, vehicle_type))
        self.con.commit()

        # Inserting transmission types
        transmission_types = ['Automatic', 'Manual', 'Electrical']
        for index, transmission_type in enumerate(transmission_types, start=5):
            insert_query = "INSERT INTO car_filters (FilterID, Transmission) VALUES (%s, %s)"
            self.cur.execute(insert_query, (index, transmission_type))
        self.con.commit()

        # Inserting mileage types
        mileage_types = ['Limited', 'Unlimited']
        for index, mileage_type in enumerate(mileage_types, start=7):
            insert_query = "INSERT INTO car_filters (FilterID, Mileage) VALUES (%s, %s)"
            self.cur.execute(insert_query, (index, mileage_type))
        self.con.commit()

        # Inserting fuel types
        fuel_types = ['Petrol', 'Diesel', 'Electric']
        for index, fuel_type in enumerate(fuel_types, start=9):
            insert_query = "INSERT INTO car_filters (FilterID, Fuel) VALUES (%s, %s)"
            self.cur.execute(insert_query, (index, fuel_type))
        self.con.commit()

        print("Car Filters inserted into Car Filters table")

    def create_table_payment(self):
        query = 'CREATE TABLE IF NOT EXISTS payment(PaymentID INT PRIMARY KEY, RentalID INT, CustomerID INT, ' \
                'CardNumber VARCHAR(16), CVV VARCHAR(4), ExpiryDate DATE, FOREIGN KEY (RentalID) REFERENCES rentals(' \
                'RentalID))'
        self.cur.execute(query)
        self.con.commit()
        print("Payment table created")


# Instantiate the FFcarrentals class
ff_car_rentals = FFcarrentals1()
