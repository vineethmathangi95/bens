SECRET_KEY = 'your_secret_key_here'

DEBUG = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'ffcarrentals1',
        'USER': 'root',
        'PASSWORD': 'Abc@1234',
        'HOST': 'localhost',
        'PORT': 8000,
    }
}

ALLOWED_HOSTS = []

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
]

# ... (Other settings and configurations)

STATIC_URL = '/static/'
