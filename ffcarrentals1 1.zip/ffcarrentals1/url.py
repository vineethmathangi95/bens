from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('user-login/', views.user_login, name='user_login'),
    path('about/', views.about_view, name='about'),
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('quote/', views.quote_view, name='quote'),
    path('payment/', views.payment_view, name='payment'),
]



