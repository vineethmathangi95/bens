from django.shortcuts import render,redirect
from django.contrib.auth.models import User

def home_view(request):
    locations = ['Birmingham', 'Coventry', 'London', 'Manchester', 'Edinburgh']
    context = {'locations': locations}
    return render(request, 'home.html', context)

def user_login(request):
    if request.method == 'POST':
        email = request.POST['user-email']
        password = request.POST['user-password']

        # Authenticate the user
        user = authenticate(request, username=email, password=password)

        if user is not None:
            # Valid credentials, log in the user
            login(request, user)
            # Redirect to a success page or any other desired page
            return redirect('success')
        else:
            # Invalid credentials, display an error message or redirect to a login failure page
            return redirect('login')  # Redirect to the login page again, you can customize this as needed
    else:
        # If the request method is not POST (e.g., GET), render the login form
        return render(request, 'login.html')

def signup_view(request):
    if request.method == 'POST':
        # Retrieve the form data from the request
        first_name = request.POST.get('user-first-name')
        last_name = request.POST.get('user-last-name')
        mobile_number = request.POST.get('user-mobile-number')
        email = request.POST.get('user-email')
        password = request.POST.get('user-password')

        # Create a new user with the form data
        user = User.objects.create_user(
            username=email,
            password=password,
            email=email,
            first_name=first_name,
            last_name=last_name
        )

        # You can perform any additional tasks here, such as sending a welcome email

        # Redirect the user to a success page
        return redirect('signup-success')

    return render(request, 'signup.html')
